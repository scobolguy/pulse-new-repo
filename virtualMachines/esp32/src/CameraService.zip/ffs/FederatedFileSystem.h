// FederatedFileSystem.h
// ESP32 Federated File System (FFS) core interface
// Supports SD (SD_MMC/SD) and LittleFS backends
// C++11, Arduino compatible

#ifndef FEDERATED_FILE_SYSTEM_H
#define FEDERATED_FILE_SYSTEM_H

#include <Arduino.h>
#include <FS.h>
#include <vector>

// FFS storage backend type
enum class FFSBackend {
    SD,
    LittleFS
};

// FFS status codes
enum class FFSStatus {
    OK = 0,
    ERR_NOT_FOUND,
    ERR_IO,
    ERR_FULL,
    ERR_JOURNAL,
    ERR_INDEX,
    ERR_INVALID_ARG,
    ERR_UNSUPPORTED
};

// Chunk size (default 512 bytes for SD sector alignment)
constexpr size_t FFS_CHUNK_SIZE = 512;

// FFS file handle (opaque)
struct FFSFileHandle {
    String logicalName;
    FFSBackend backend;
    File file;
    // Add chunk index, position, etc. as needed
};

// Chunk metadata structure
struct FFSChunkInfo {
    size_t chunkId;
    size_t offset;
    size_t length;
};

enum class FFSMountType {
    LocalAlias,
    Peer
};

struct FFSMountEntry {
    String mountPoint;
    String targetPath;
    String peerId;
    FFSMountType type;
    bool readOnly;
};

// File handle table for open files (simple integer handle)
#include <map>

struct FFSOpenFile {
    File file;
    String mode;
};

class FederatedFileSystem {
public:
    FederatedFileSystem();
    bool begin(FFSBackend backend, fs::FS &fs, const String &basePath = "/");
    // File handle/line I/O
    int openFile(const String &logicalName, const String &mode);
    bool closeFile(int handle);
    bool readLine(int handle, String &outLine);
    bool writeLine(int handle, const String &line);

    // Basic file ops
    FFSStatus write(const String &logicalName, const uint8_t *data, size_t len);
    FFSStatus read(const String &logicalName, std::vector<uint8_t> &outData);
    FFSStatus remove(const String &logicalName);
    FFSStatus listFiles(std::vector<String> &outNames);

    // Advanced FFS API
    // Chunked storage
    FFSStatus appendChunk(const String &logicalName, const uint8_t *data, size_t len, size_t &outChunkId);
    FFSStatus readChunk(const String &logicalName, size_t chunkId, std::vector<uint8_t> &outData);
    FFSStatus listChunks(const String &logicalName, std::vector<FFSChunkInfo> &outChunks);

    // Journaling/atomic commit
    FFSStatus beginTransaction();
    FFSStatus commitTransaction();
    FFSStatus abortTransaction();
    bool inTransaction() const;

    // Sync (flush to media)
    FFSStatus sync();

    // Federation (stub)
    FFSStatus pushFileToPeer(const String &logicalName, const String &peerId);
    FFSStatus fetchFileFromPeer(const String &logicalName, const String &peerId);

    // Mounts
    FFSStatus addMountPoint(const String &mountPoint, const String &targetPath, FFSMountType type, const String &peerId = "", bool readOnly = true);
    FFSStatus removeMountPoint(const String &mountPoint);
    std::vector<FFSMountEntry> listMountPoints() const;
    FFSStatus reloadMountPoints();
    FFSStatus saveMountPoints() const;

private:
    static constexpr const char* MOUNT_TABLE_PATH = "/ffs/.mounts.json";

    struct ResolvedPath {
        bool mounted = false;
        bool remote = false;
        bool readOnly = true;
        String logicalPath;
        String resolvedPath;
        String peerId;
        String mountPoint;
    };

    FFSBackend _backend;
    fs::FS *_fs;
    String _basePath;
    bool _inTransaction;
    int _nextHandle = 1;
    std::map<int, FFSOpenFile> _openFiles;
    std::vector<FFSMountEntry> _mounts;
    // TODO: chunk index, journal, transaction log, federation state, etc.

    String makeAbsolutePath(const String &logicalName) const;
    ResolvedPath resolvePath(const String &logicalName) const;
    FFSStatus readLocalFile(const String &path, std::vector<uint8_t> &outData) const;
    FFSStatus writeLocalFile(const String &path, const uint8_t *data, size_t len);
    bool removeLocalFile(const String &path) const;
    void ensureMountParentDirectory() const;
};

#endif // FEDERATED_FILE_SYSTEM_H
